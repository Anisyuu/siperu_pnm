<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user', function (Blueprint $table) {
            // $table->id();
            $table->string('nomor_induk', 20)->primary();
            $table->string('nama_lengkap', 150);
            $table->string('no_telp', 20)->nullable();
            $table->string('email', 100)->unique();
            $table->string('password', 60);

            $table->string('google_id')->nullable()->unique();
            $table->string('avatar')->nullable();

            $table->enum('is_active', ['active', 'inactive'])->default('active');

            // WAJIB untuk auth Laravel
            $table->rememberToken();

            // Soft delete standar Laravel
            $table->softDeletes();
            $table->timestamps();
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
