<?php

namespace App\Http\Controllers\Kasubag;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Jadwal;
use App\Models\Peminjaman;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function dashboard(Request $request)
    {
        $user = Auth::user();
        $userId = $user->nomor_induk;

        $userRoles = $user->roles
            ->pluck('nama')
            ->map(fn ($role) => strtolower(trim($role)))
            ->filter()
            ->values()
            ->toArray();

        $jenisPemohonDiizinkan = DB::table('alur_verifikasi')
            ->whereIn(DB::raw('LOWER(TRIM(role_verifikator))'), $userRoles)
            ->pluck('jenis_pemohon')
            ->map(fn ($jenis) => strtolower(trim($jenis)))
            ->unique()
            ->values()
            ->toArray();

        $anchor = $request->filled('tanggal')
            ? Carbon::parse($request->tanggal)
            : now();

        $weekStart = $anchor->copy()->startOfWeek(Carbon::MONDAY);
        $weekEnd   = $weekStart->copy()->addDays(6);

        /*
        |--------------------------------------------------------------------------
        | STAT CARD KASUBAG SEBAGAI VERIFIKATOR
        |--------------------------------------------------------------------------
        */

        $pendingPeminjaman = Peminjaman::with([
                'pemohon.roles',
                'ruangan.jenisRuangan',
                'verifikasi',
            ])
            ->where('status', 'pending')
            ->whereHas('pemohon.roles', function ($q) use ($jenisPemohonDiizinkan) {
                $q->whereIn(DB::raw('LOWER(TRIM(nama))'), $jenisPemohonDiizinkan);
            })
            ->get();

        $menunggu = $pendingPeminjaman
            ->filter(fn ($peminjaman) => $this->perluDiverifikasiOlehUser($peminjaman, $userRoles, $userId))
            ->count();

        $disetujui = Peminjaman::query()
            ->whereHas('verifikasi', function ($q) use ($userId) {
                $q->where('id_verifikator', $userId)
                    ->where('status_verifikasi', 'disetujui');
            })
            ->count();

        $ditolak = Peminjaman::query()
            ->whereHas('verifikasi', function ($q) use ($userId) {
                $q->where('id_verifikator', $userId)
                    ->where('status_verifikasi', 'ditolak');
            })
            ->count();

        $total = $menunggu + $disetujui + $ditolak;

        /*
        |--------------------------------------------------------------------------
        | KALENDER JADWAL DAN PEMINJAMAN
        |--------------------------------------------------------------------------
        */

        $jadwal = Jadwal::with([
                'ruangan.gedung.kampus',
            ])
            ->whereDate('tanggal_mulai', '<=', $weekEnd->toDateString())
            ->whereDate('tanggal_selesai', '>=', $weekStart->toDateString())
            ->orderBy('tanggal_mulai')
            ->orderBy('waktu_mulai')
            ->get();

        $peminjaman = Peminjaman::with([
                'ruangan.gedung.kampus',
                'pemohon',
            ])
            ->where('status', 'disetujui')
            ->whereDate('tanggal_mulai', '<=', $weekEnd->toDateString())
            ->whereDate('tanggal_selesai', '>=', $weekStart->toDateString())
            ->orderBy('tanggal_mulai')
            ->orderBy('waktu_mulai')
            ->get();

        $events = collect()
            ->merge($this->mapJadwal($jadwal, $weekStart, $weekEnd))
            ->merge($this->mapPeminjaman($peminjaman, $weekStart, $weekEnd))
            ->sortBy([
                ['tanggal', 'asc'],
                ['waktu_mulai', 'asc'],
            ])
            ->values();

        $eventsByDate = $events
            ->groupBy(fn ($event) => Carbon::parse($event['tanggal'])->toDateString())
            ->map(function ($dayEvents) {
                $dayEvents = $dayEvents
                    ->sortBy([
                        ['waktu_mulai', 'asc'],
                        ['waktu_selesai', 'asc'],
                    ])
                    ->values();

                $columns = [];
                $result = collect();

                foreach ($dayEvents as $event) {
                    $eventStart = Carbon::parse($event['waktu_mulai']);
                    $eventEnd   = Carbon::parse($event['waktu_selesai']);

                    $placedColumn = null;

                    foreach ($columns as $columnIndex => $lastEventEnd) {
                        if ($eventStart->gte($lastEventEnd)) {
                            $placedColumn = $columnIndex;
                            break;
                        }
                    }

                    if ($placedColumn === null) {
                        $placedColumn = count($columns);
                    }

                    $columns[$placedColumn] = $eventEnd;
                    $event['overlap_index'] = $placedColumn;

                    $result->push($event);
                }

                $overlapTotal = max(1, count($columns));

                return $result->map(function ($event) use ($overlapTotal) {
                    $event['overlap_total'] = $overlapTotal;
                    return $event;
                });
            });

        $days = collect(range(0, 6))
            ->map(fn ($i) => $weekStart->copy()->addDays($i));

        return view('layouts.kasubag.dashboard', [
            'events'       => $events,
            'eventsByDate' => $eventsByDate,
            'days'         => $days,
            'weekStart'    => $weekStart,
            'weekEnd'      => $weekEnd,
            'monthLabel'   => $weekStart->locale('id')->translatedFormat('F Y'),

            'total'        => $total,
            'menunggu'     => $menunggu,
            'disetujui'    => $disetujui,
            'ditolak'      => $ditolak,
        ]);
    }

    private function perluDiverifikasiOlehUser($peminjaman, array $userRoles, string $userId): bool
    {
        if ($peminjaman->verifikasi->contains('id_verifikator', $userId)) {
            return false;
        }

        $jenisPemohon = strtolower(trim(
            $peminjaman->pemohon->roles->pluck('nama')->first()
                ?? $peminjaman->pemohon->role
                ?? ''
        ));

        if ($jenisPemohon === '') {
            return false;
        }

        $jenisRuangSlug = strtolower(trim($peminjaman->ruangan->jenisRuangan->slug ?? ''));
        $jenisRuangNama = strtolower(trim($peminjaman->ruangan->jenisRuangan->nama ?? ''));

        $isLab = str_contains($jenisRuangSlug, 'lab')
            || str_contains($jenisRuangNama, 'lab');

        $alur = DB::table('alur_verifikasi')
            ->whereRaw('LOWER(TRIM(jenis_pemohon)) = ?', [$jenisPemohon])
            ->when(!$isLab, function ($q) {
                $q->whereRaw('LOWER(TRIM(role_verifikator)) != ?', ['kalab']);
            })
            ->orderBy('urutan')
            ->get();

        if ($alur->isEmpty()) {
            return false;
        }

        $riwayat = $peminjaman->verifikasi
            ->sortBy('urutan')
            ->values();

        foreach ($alur as $step) {
            $roleVerifikator = strtolower(trim($step->role_verifikator));

            $verifikasiStep = $riwayat->first(function ($item) use ($step, $roleVerifikator) {
                $urutanSama = isset($item->urutan)
                    && (int) $item->urutan === (int) $step->urutan;

                $roleSama = isset($item->role_verifikator)
                    && strtolower(trim($item->role_verifikator)) === $roleVerifikator;

                return $urutanSama || $roleSama;
            });

            if (!$verifikasiStep) {
                return in_array($roleVerifikator, $userRoles);
            }

            if ($verifikasiStep->status_verifikasi === 'ditolak') {
                return false;
            }

            if ($verifikasiStep->status_verifikasi !== 'disetujui') {
                return in_array($roleVerifikator, $userRoles);
            }
        }

        return false;
    }

    private function mapJadwal($data, Carbon $weekStart, Carbon $weekEnd)
    {
        return $data->flatMap(function ($item) use ($weekStart, $weekEnd) {
            $tanggalMulai   = Carbon::parse($item->tanggal_mulai)->startOfDay();
            $tanggalSelesai = Carbon::parse($item->tanggal_selesai)->startOfDay();

            $start = $tanggalMulai->greaterThan($weekStart)
                ? $tanggalMulai
                : $weekStart->copy();

            $end = $tanggalSelesai->lessThan($weekEnd)
                ? $tanggalSelesai
                : $weekEnd->copy();

            $lokasi = $this->lokasiRuangan($item->ruangan);

            $events = collect();

            for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                $events->push([
                    'tanggal'           => $date->toDateString(),
                    'waktu_mulai'       => $item->waktu_mulai,
                    'waktu_selesai'     => $item->waktu_selesai,

                    'title'             => $item->kegiatan,
                    'penanggung_jawab'  => $item->penanggung_jawab ?? '-',
                    'catatan'           => $item->catatan ?? '-',
                    'type'              => 'jadwal',

                    'kampus'            => $lokasi['kampus'],
                    'gedung'            => $lokasi['gedung'],
                    'lantai'            => $lokasi['lantai'],
                    'ruangan'           => $lokasi['ruangan'],
                ]);
            }

            return $events;
        });
    }

    private function mapPeminjaman($data, Carbon $weekStart, Carbon $weekEnd)
    {
        return $data->flatMap(function ($item) use ($weekStart, $weekEnd) {
            $tanggalMulai   = Carbon::parse($item->tanggal_mulai)->startOfDay();
            $tanggalSelesai = Carbon::parse($item->tanggal_selesai)->startOfDay();

            $start = $tanggalMulai->greaterThan($weekStart)
                ? $tanggalMulai
                : $weekStart->copy();

            $end = $tanggalSelesai->lessThan($weekEnd)
                ? $tanggalSelesai
                : $weekEnd->copy();

            $lokasi = $this->lokasiRuangan($item->ruangan);

            $penanggungJawab = data_get($item, 'pemohon.nama_lengkap')
                ?? data_get($item, 'pemohon.nama')
                ?? data_get($item, 'pemohon.nomor_induk')
                ?? '-';

            $events = collect();

            for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                $events->push([
                    'tanggal'           => $date->toDateString(),
                    'waktu_mulai'       => $item->waktu_mulai,
                    'waktu_selesai'     => $item->waktu_selesai,

                    'title'             => $item->kegiatan ?? 'Peminjaman Ruangan',
                    'penanggung_jawab'  => $penanggungJawab,
                    'catatan'           => $item->catatan ?? '-',
                    'type'              => 'peminjaman',

                    'kampus'            => $lokasi['kampus'],
                    'gedung'            => $lokasi['gedung'],
                    'lantai'            => $lokasi['lantai'],
                    'ruangan'           => $lokasi['ruangan'],
                ]);
            }

            return $events;
        });
    }

    private function lokasiRuangan($ruangan): array
    {
        $kampus = data_get($ruangan, 'kampus.nama_kampus')
            ?? data_get($ruangan, 'kampus.nama')
            ?? data_get($ruangan, 'gedung.kampus.nama_kampus')
            ?? data_get($ruangan, 'gedung.kampus.nama')
            ?? data_get($ruangan, 'nama_kampus');

        $gedung = data_get($ruangan, 'gedung.nama_gedung')
            ?? data_get($ruangan, 'gedung.nama')
            ?? data_get($ruangan, 'nama_gedung');

        $lantai = data_get($ruangan, 'lantai.nama_lantai')
            ?? data_get($ruangan, 'lantai.nama')
            ?? data_get($ruangan, 'nama_lantai')
            ?? data_get($ruangan, 'lantai');

        $namaRuangan = data_get($ruangan, 'nama_ruang')
            ?? data_get($ruangan, 'nama')
            ?? data_get($ruangan, 'kode_ruang');

        return [
            'kampus'  => $this->nilaiLokasi($kampus),
            'gedung'  => $this->nilaiLokasi($gedung),
            'lantai'  => $this->nilaiLokasi($lantai),
            'ruangan' => $this->nilaiLokasi($namaRuangan),
        ];
    }

    private function nilaiLokasi($value): string
    {
        if ($value === null || $value === '') {
            return '-';
        }

        if (is_object($value) || is_array($value)) {
            return '-';
        }

        return (string) $value;
    }
}
